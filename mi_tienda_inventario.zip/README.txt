# Mi Tienda - Inventario y Ventas

## Cómo abrir la página
1. Descarga/descomprime la carpeta.
2. Abre `index.html` con Chrome, Edge o Firefox.
3. Los datos se guardan actualmente en el navegador mediante `localStorage`.

## Funciones incluidas
- Registro, edición y eliminación de productos.
- Nombre, marca, detalle, precio y stock.
- Búsqueda de productos.
- Registro de ventas.
- Cliente.
- Efectivo o transferencia.
- Pagado o pendiente.
- Descuento automático del stock.
- Dashboard y reportes.
- Alertas de bajo inventario.
- Campo preparado para URL de Google Apps Script.

## Google Sheets
La conexión todavía no está activa. La siguiente etapa es crear un Google Apps Script que reciba/consulte los productos y ventas y sustituya el almacenamiento local por Google Sheets.
