const $=id=>document.getElementById(id);
const money=n=>"L. "+Number(n||0).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
let products=JSON.parse(localStorage.getItem("mt_products")||"[]");
let sales=JSON.parse(localStorage.getItem("mt_sales")||"[]");

function save(){localStorage.setItem("mt_products",JSON.stringify(products));localStorage.setItem("mt_sales",JSON.stringify(sales));}
function today(){return new Date().toISOString().slice(0,10)}
$("saleDate").value=today();

document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>showSection(b.dataset.section)));
function showSection(id){
 document.querySelectorAll(".section").forEach(s=>s.classList.remove("active"));
 $(id).classList.add("active");
 document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.section===id));
 const names={inicio:["Mi Tienda","Productos variados"],inventario:["Inventario","Administra tus productos"],ventas:["Ventas","Registra tus ventas"],reportes:["Reportes","Resumen de tu tienda"],configuracion:["Configuración","Conecta servicios externos"]};
 $("pageTitle").textContent=names[id][0];$("pageSubtitle").textContent=names[id][1];renderAll();
}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2200)}
function renderAll(){renderProducts();renderSales();updateDashboard();populateSaleProducts();renderLow()}
function renderProducts(){
 const q=($("productSearch")?.value||"").toLowerCase();
 const list=products.filter(p=>(p.name+p.brand+p.id).toLowerCase().includes(q));
 $("productsTable").innerHTML=list.map(p=>`<tr><td>${p.id}</td><td><strong>${esc(p.name)}</strong></td><td>${esc(p.brand)}</td><td>${esc(p.detail)}</td><td>${money(p.price)}</td><td><span class="badge ${p.stock===0?"out":p.stock<=3?"low":""}">${p.stock}</span></td><td><button class="action" onclick="editProduct('${p.id}')">✏️</button><button class="action delete" onclick="deleteProduct('${p.id}')">🗑️</button></td></tr>`).join("")||`<tr><td colspan="7">No hay productos registrados.</td></tr>`;
 $("homeProducts").innerHTML=products.slice(-6).reverse().map(p=>`<tr><td>${p.id}</td><td>${esc(p.name)}</td><td>${esc(p.brand)}</td><td>${money(p.price)}</td><td><span class="badge ${p.stock===0?"out":p.stock<=3?"low":""}">${p.stock}</span></td></tr>`).join("")||`<tr><td colspan="5">Aún no hay productos.</td></tr>`;
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
$("productForm").addEventListener("submit",e=>{
 e.preventDefault(); const edit=$("productId").value;
 const data={id:edit||"PRD"+String(products.length+1).padStart(3,"0"),name:$("productName").value.trim(),brand:$("brand").value.trim(),detail:$("detail").value.trim(),price:+$("price").value,stock:+$("stock").value};
 if(edit){const i=products.findIndex(p=>p.id===edit);products[i]=data;toast("Producto actualizado");}else{products.push(data);toast("Producto guardado");}
 save();resetProductForm();renderAll();
});
function editProduct(id){const p=products.find(x=>x.id===id);if(!p)return;$("productId").value=p.id;$("productName").value=p.name;$("brand").value=p.brand;$("detail").value=p.detail;$("price").value=p.price;$("stock").value=p.stock;$("cancelEdit").classList.remove("hidden");showSection("inventario");window.scrollTo({top:0,behavior:"smooth"})}
$("cancelEdit").onclick=resetProductForm;
function resetProductForm(){$("productForm").reset();$("productId").value="";$("cancelEdit").classList.add("hidden")}
function deleteProduct(id){if(confirm("¿Eliminar este producto?")){products=products.filter(p=>p.id!==id);save();renderAll();toast("Producto eliminado")}}
$("productSearch").addEventListener("input",renderProducts);

function populateSaleProducts(){
 const current=$("saleProduct").value;
 $("saleProduct").innerHTML='<option value="">Selecciona un producto</option>'+products.filter(p=>p.stock>0).map(p=>`<option value="${p.id}">${esc(p.name)} — ${money(p.price)} (${p.stock} disponibles)</option>`).join("");
 if(products.some(p=>p.id===current&&p.stock>0))$("saleProduct").value=current;
 updateSaleTotal();
}
$("saleProduct").addEventListener("change",updateSaleTotal);$("saleQty").addEventListener("input",updateSaleTotal);
function updateSaleTotal(){const p=products.find(x=>x.id===$("saleProduct").value);$("salePrice").value=p?money(p.price):money(0);$("saleTotal").textContent=money(p?(p.price*(+$("saleQty").value||0)):0)}
$("saleForm").addEventListener("submit",e=>{
 e.preventDefault();const p=products.find(x=>x.id===$("saleProduct").value),qty=+$("saleQty").value;
 if(!p)return toast("Selecciona un producto"); if(qty<1||qty>p.stock)return toast("Cantidad superior al stock disponible");
 const sale={id:"V"+Date.now(),date:$("saleDate").value,productId:p.id,product:p.name,qty,price:p.price,total:p.price*qty,customer:$("customer").value.trim(),method:$("paymentMethod").value,status:$("paymentStatus").value};
 p.stock-=qty;sales.push(sale);save();e.target.reset();$("saleDate").value=today();$("saleQty").value=1;toast("Venta registrada correctamente");renderAll();
});
function renderSales(){
 $("salesTable").innerHTML=sales.slice().reverse().map(s=>`<tr><td>${s.date}</td><td>${esc(s.product)}</td><td>${esc(s.customer)}</td><td>${money(s.total)}</td><td><span class="badge ${s.method==="Transferencia"?"transfer":""}">${s.method}</span></td><td><span class="badge ${s.status==="Pendiente"?"pending":""}">${s.status}</span></td></tr>`).join("")||`<tr><td colspan="6">Aún no hay ventas.</td></tr>`;
 $("homeSales").innerHTML=sales.slice().reverse().slice(0,6).map(s=>`<tr><td>${s.date}</td><td>${esc(s.product)}</td><td>${esc(s.customer)}</td><td>${money(s.total)}</td></tr>`).join("")||`<tr><td colspan="4">Aún no hay ventas.</td></tr>`;
}
function updateDashboard(){
 const t=today(),todaySales=sales.filter(s=>s.date===t),todayTotal=todaySales.reduce((a,s)=>a+s.total,0),pending=sales.filter(s=>s.status==="Pendiente").reduce((a,s)=>a+s.total,0),low=products.filter(p=>p.stock<=3);
 $("statProducts").textContent=products.length;$("statSales").textContent=money(todayTotal);$("statLow").textContent=low.length;$("statPending").textContent=money(pending);
 $("reportTotal").textContent=money(sales.reduce((a,s)=>a+s.total,0));$("reportPending").textContent=money(pending);$("reportUnits").textContent=products.reduce((a,p)=>a+p.stock,0);
}
function renderLow(){$("lowTable").innerHTML=products.filter(p=>p.stock<=3).sort((a,b)=>a.stock-b.stock).map(p=>`<tr><td>${esc(p.name)}</td><td>${esc(p.brand)}</td><td><span class="badge ${p.stock===0?"out":"low"}">${p.stock}</span></td></tr>`).join("")||`<tr><td colspan="3">No hay productos con poco stock.</td></tr>`}
function clock(){$("clock").textContent=new Date().toLocaleString("es-HN",{dateStyle:"medium",timeStyle:"short"})}
setInterval(clock,1000);clock();

$("saveConfig").onclick=()=>{localStorage.setItem("mt_sheets_url",$("sheetsUrl").value.trim());toast("Configuración guardada")};
$("sheetsUrl").value=localStorage.getItem("mt_sheets_url")||"";
renderAll();
